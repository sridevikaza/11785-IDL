def question_1():
    return "b"

def question_2():
    return "c"

def question_3():
    return "b"

def question_4():
    return "b"

def question_5():
    return "a"
